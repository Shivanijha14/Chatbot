# Chatbot Java GUI Client Server using Database

Implementasi Chatbot dalam socket dan menggunakan Database sebagai keyword.

Data didatabase masih sedikit, jadi botnya masih butuh banyakk data lagi.
